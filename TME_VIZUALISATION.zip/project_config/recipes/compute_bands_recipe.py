# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# ## Renommage des colonnes

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
import re
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
from dataiku import insights
# Read recipe inputs
bands = dataiku.Dataset("bands")
bands_df = bands.get_dataframe()


# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

bands_recipe_df = bands_df # For this sample code, simply copy input to output
# Write recipe outputs
bands_recipe = dataiku.Dataset("bands_recipe")
bands_recipe.write_with_schema(bands_recipe_df)


s ="""
    1. timestamp: numeric;19500101 - 21001231
    2. cylinder number: nominal
    3. customer: nominal; 
    4. job number: nominal; 
    5. grain screened: nominal; yes, no 
    6. ink color: nominal;  key, type 
    7. proof on ctd ink:  nominal;  yes, no  
    8. blade mfg: nominal;  benton, daetwyler, uddeholm 
    9. cylinder division: nominal;  gallatin, warsaw, mattoon 
    10. paper type: nominal;  uncoated, coated, super 
    11. ink type: nominal;  uncoated, coated, cover 
    12. direct steam: nominal; use; yes, no *
    13. solvent type: nominal;  xylol, lactol, naptha, line, other 
    14. type on cylinder:  nominal;  yes, no  
    15. press type: nominal; use; 70 wood hoe, 70 motter, 70 albert, 94 motter 
    16. press: nominal;  821, 802, 813, 824, 815, 816, 827, 828 
    17. unit number: nominal;  1, 2, 3, 4, 5, 6, 7, 8, 9, 10 
    18. cylinder size: nominal;  catalog, spiegel, tabloid 
    19. paper mill location: nominal; north us, south us, canadian, scandanavian, mid european
    20. plating tank: nominal; 1910, 1911, other 
    21. proof cut: numeric;  0-100 
    22. viscosity: numeric;  0-100 
    23. caliper: numeric;  0-1.0 
    24. ink temperature: numeric;  5-30 
    25. humifity: numeric;  5-120 
    26. roughness: numeric;  0-2 
    27. blade pressure: numeric;  10-75 
    28. varnish pct: numeric;  0-100 
    29. press speed: numeric;  0-4000 
    30. ink pct: numeric;  0-100 
    31. solvent pct: numeric;  0-100 
    32. ESA Voltage: numeric;  0-16 
    33. ESA Amperage: numeric;  0-10 
    34. wax: numeric ;  0-4.0
    35. hardener:  numeric; 0-3.0 
    36. roller durometer:  numeric;  15-120 
    37. current density:  numeric;  20-50 
    38. anode space ratio:  numeric;  70-130 
    39. chrome content: numeric; 80-120 
    40. band type: nominal; class; band, no band *"""
tmp = []
iterator = re.finditer("^. .*:",s,re.MULTILINE)
for match in iterator:
    tmp.append(match.group()[7:-1])

bands_recipe_df.columns = tmp    
bands_recipe_df

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# ## Préparation des données

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
bands_recipe_df = bands_recipe_df.drop(columns=['timestamp', 'customer', 'job number', 'grain screened', 'ink color',
               'proof on ctd ink', 'blade mfg', 'cylinder division', ' paper type', ' ink type', ' direct steam', 
              ' roller durometer',' solvent pct' ,' solvent type', ' viscosity',' type on cylinder', ' press type', ' press', ' band type','cylinder number',
             ' roughness' ,' varnish pct', ' ink temperature' ,' humifity',' press speed',' ink pct',' plating tank',' cylinder size',' current density',' anode space ratio',' chrome content',' ESA Voltage',' ESA Amperage',' paper mill location'])
bands_recipe_df.columns
bands_recipe_df.drop(bands_recipe_df.loc[bands_recipe_df[' proof cut']=='?'].index, inplace=True)
bands_recipe_df.drop(bands_recipe_df.loc[bands_recipe_df[' blade pressure']=='?'].index, inplace=True)
bands_recipe_df.drop(bands_recipe_df.loc[bands_recipe_df[' hardener']=='?'].index, inplace=True)
bands_recipe_df.drop(bands_recipe_df.loc[bands_recipe_df[' caliper']=='?'].index, inplace=True)
bands_recipe_df.drop(bands_recipe_df.loc[bands_recipe_df[' wax']=='?'].index, inplace=True)



index_with_nan = bands_recipe_df.index[bands_recipe_df.isnull().any(axis=1)]
bands_recipe_df.drop(index_with_nan,0,inplace=True)
bands_recipe_df[' proof cut'] = pd.to_numeric(bands_recipe_df[' proof cut'], errors='coerce')
bands_recipe_df[' blade pressure'] = pd.to_numeric(bands_recipe_df[' blade pressure'], errors='coerce')
bands_recipe_df[' hardener'] = pd.to_numeric(bands_recipe_df[' hardener'], errors='coerce')
bands_recipe_df[' caliper'] = pd.to_numeric(bands_recipe_df[' caliper'], errors='coerce')
bands_recipe_df[' wax'] = pd.to_numeric(bands_recipe_df[' wax'], errors='coerce')

bands_recipe_df

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
bands_recipe_df.info()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# ## Tables de contigence

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
bands_recipe_df[' proof cut']=pd.cut(bands_recipe_df[' proof cut'],[20,30.,40.,50.,60.,70.],labels=[20,30,40,50,60])
bands_recipe_df[' blade pressure']=pd.cut(bands_recipe_df[' blade pressure'],[0,20,30,40,50,60,70],labels=[20,30,40,50,60,65])
bands_recipe_df[' hardener']=pd.cut(bands_recipe_df[' hardener'],[0,0.5,1,1.5,2],labels=[0.5,1,1.5,2])
bands_recipe_df[' caliper']=pd.cut(bands_recipe_df[' caliper'],[0,0.200,0.250,0.300,0.350,0.400,0.450,0.500],labels=[0.200,0.250,0.300,0.350,0.400,0.450,0.500])
bands_recipe_df[' wax']=pd.cut(bands_recipe_df[' wax'],[0,1.5,2,2.5,3,3.5],labels=[1.5,2,2.5,3,3.5])
data_crosstab = pd.crosstab(bands_recipe_df[' proof cut'], bands_recipe_df[' blade pressure'], margins = False)
print(data_crosstab)
print('\n')
print('\n')
print('\n')
data_crosstab = pd.crosstab(bands_recipe_df[' proof cut'], bands_recipe_df[' blade pressure'], margins = False)
print(data_crosstab)
print('\n')
print('\n')
print('\n')
data_crosstab = pd.crosstab(bands_recipe_df[' hardener'], bands_recipe_df[' wax'], margins = False)
print(data_crosstab)
print('\n')
print('\n')
print('\n')
data_crosstab = pd.crosstab(bands_recipe_df[' caliper'], bands_recipe_df[' blade pressure'], margins = False)
print(data_crosstab)